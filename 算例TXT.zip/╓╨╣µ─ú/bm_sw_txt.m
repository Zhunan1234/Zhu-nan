clc
clear
file_mat=dir('*.mat');
mat_num=size(file_mat,1);
for n=1:mat_num        %ѭ������������
oldfile =file_mat(n).name;  
load(oldfile);
%% ����׼������ȡ����ӦTXT���ݴ洢��ʽ
%���������ܺı�
standby=round(standby);
ma=0;
ma_length=1;
standby_set=cell(fa_num,wo_num_max);
for i=1:fa_num
    for ii=1:wo_num_max
        s=size(machine_set_wo{i,ii},2);
        ma=ma+s;
    standby_set{i,ii}=standby(1,ma_length:ma);
    ma_length=ma_length+s;
    end
end
num1=0;
for j=1:job_num
    job_rank=ope_set(1,j);
    mark1=2;
    for oper_rank=1:ope_set(2,j)
        if job_rank==1
            NO=oper_rank;
        else
            NO=sum(ope_set(2,1:job_rank-1))+oper_rank;
        end
        mach_rank_set=job_infor(NO).mach_rank;
%         intime=job_infor(NO).int_time;
        [row,col]=size(job_infor(NO).mach_rank);
        mach_num=0;   %��¼�ܵĻ�����
        mach_num_all=zeros(1,fa_num);
        mark=1;
        %��һ�д�Ź����ţ��ڶ��г���ţ�������ǻ���+�ӹ�ʱ�����
        for f=1:row
            for w=1:col
                if ~isempty(mach_rank_set{f,w})     %%���ڼӹ�����
                    fa_rank=job_infor(NO).fa_rank(f,1);
                    wo_rank=job_infor(NO).wo_rank(f,w);
                    infor_mach(mark,1)=fa_rank;
                    infor_mach(mark,2)=wo_rank;
                    num=3;
                    infor_mach(mark,num)=inf;
                    num=num+1;
                    ma_set=mach_rank_set{f,w};
                    protime_set=job_infor(NO).pro_time{f,w};
                    procost_set=job_infor(NO).unit_cost{f,w};
                    pover_set=job_infor(NO).power{f,w};
                    [~,col1]=sort(ma_set);
                    ma_set=ma_set(col1);
                    protime_set=protime_set(col1);
                    procost_set=procost_set(col1);
                    pover_set=pover_set(col1);
                    m=size(ma_set,2);
                    mach_num=mach_num+m;
                    for k=1:m
                        infor_mach(mark,num)=ma_set(k);
                        infor_mach(mark,num+1)=protime_set(k);
                        infor_mach(mark,num+2)=procost_set(k);
                        infor_mach(mark,num+3)=pover_set(k);
                        infor_mach(mark,num+4)=standby_set{fa_rank,wo_rank}(1,ma_set(k));
                        num=num+5;
                    end
                    if k==m
                        infor_mach(mark,num)=inf;
                    end
                end
                mark=mark+1;
            end
            mach_num_all(f)=mach_num;
            mach_num=0;
        end
        TXT(j,1)=oper_rank;
        if mark1==2
            TXT(j,mark1)=sum(mach_num_all);
        else
            TXT(j,mark1+1)=sum(mach_num_all);
            mark1=mark1+1;
        end
        for kk=1:size(infor_mach,1)
            pro_inf=infor_mach(kk,:);
            [~,in]=find(pro_inf==0);
            pro_inf(in)=[];
            len=size(pro_inf,2);
            if ~isempty(len)
                TXT(j,mark1+1:mark1+len)=pro_inf;
                mark1=mark1+len;
            end
        end
        clear infor_mach
    end
end
%% ���ϸ������ת����TXT�ļ�
filename=strcat('DC',oldfile(1:2),'_',num2str(job_num),'��',num2str(fa_num),'��',num2str(wo_num_max),'��',num2str(machine_num),'.txt');
fid = fopen(filename,'wt');
fprintf(fid,'%s','The number of jobs:');
fprintf(fid,'%d\n',job_num);
fprintf(fid,'%s','The maximum number of factories:');
fprintf(fid,'%d\n',3);
fprintf(fid,'%s','The maximum number of workshops in each factory:');
fprintf(fid,'%d\n',3);
fprintf(fid,'%s','The maximum number of machines in each workshop:');
fprintf(fid,'%d\n',5);
fprintf(fid,'%s','The available number of machines in each workshop:');
fprintf(fid,'%s\n','1:2');                                                                                                                         
for i=1:job_num
    vector=TXT(i,:);
    [~,col]=find(vector==0);
    vector(col)=[];
    mark3=1;
    for k=1:size(vector,2)
        number=vector(k);
        if number==inf
            if mod(mark3,2)==1
                number=strcat('(');
                mark3=mark3+1;
                fprintf(fid,'%s',number);
            else
                number=strcat(')');
                mark3=mark3+1;
                fprintf(fid,'%s',number);
                fprintf(fid,'%c',' ');
            end
        else
            fprintf(fid,'%d',number);
            fprintf(fid,'%c',' ');
        end
    end
    if i<job_num
    fprintf(fid,'\n');
    end
end
fclose(fid);
clear TXT 
end