function [Population_indiv]=Unfi_VFWM_search2(Unfi_initial_time,Population_indiv,elites_cp,length,job_infor,machine_num,fa_num,wo_num_max,unfi_oper_set,finish_oper_energy,finish_oper,ope_set,initial_schedule,time)
%% search direction
% OS段，关键工序上随机产生两个位置，互换在染色体上的位置
% Others段，从加工机器中选择加工时间最小的机器（最优），回溯对应的额工厂、车间
decode_ns=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'work_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
chromesome=Population_indiv.chromesome;
if rand>0.5
    %% OS段邻域搜索
    if length>1
        IP=randperm(length,2);
        num=size(IP,2);
        for i=1:num
            j_rank=elites_cp(IP(i),1);
            op_rank=elites_cp(IP(i),2);
            [z0,~]=find(elites_cp(:,1)==j_rank);
            [z1,~]=find(elites_cp(z0,2)==op_rank);
            [~,pos]=find(chromesome(4,:)==j_rank);
            pos1(i)=pos(1,z1);
        end
        mark=chromesome(4,pos1(1));
        chromesome(4,pos1(1))=chromesome(4,pos1(2));      %关键工序上的N6领域搜素
        chromesome(4,pos1(2))=mark;
    else
    end
else
    %% Others 领域搜素
    IP1=randperm(length,1);
    job_rank=elites_cp(IP1,1);
    oper_rank=elites_cp(IP1,2);
    NO=sum(ope_set(2,1:job_rank-1))+oper_rank;
    protime_set=job_infor(NO).pro_time;
    [row,col]=size(protime_set);
    min_vector=zeros(row,col);
    for f=1:row
        for w=1:col
            V=protime_set{f,w};
            if isempty(V)
                min_vector(f,w)=inf;
            else
                min_vector(f,w)=min(V);
            end
        end
    end
    VV=reshape(min_vector,1,row*col);
    min_pro=min(VV);
    [row1,col1]=find(min_pro==min_vector);
    R=randperm(size(row1,1),1);    %%如果位置是1，并不表示工厂、车间就是响应的数字，容易出错
    fa_rank_set=job_infor(NO).fa_rank;
    fa_rank_new=fa_rank_set(row1(R),1);
    [~,n0]=find(unfi_oper_set(1,:)==job_rank);
    [~,n1]=find(unfi_oper_set(2,n0)==oper_rank);
    n2=n0(n1);
    chromesome(1,n2)=fa_rank_new;   %新的工厂
    wo_rank_set=job_infor(NO).wo_rank;
    wo_rank_new=wo_rank_set(row1(R),col1(R));   %新的车间
    chromesome(2,n2)=wo_rank_new;
    protime_set1=protime_set{row1(R),col1(R)};
    [~,IP]=find(protime_set1==min_pro);
    IP1=randperm(size(IP,2),1);
    ma_rank_set=job_infor(NO).mach_rank{row1(R),col1(R)};
    ma_rank_new=ma_rank_set(IP1);
    chromesome(3,n2)=ma_rank_new;          %新的机器
    chromesome(5,n2)=min_pro;              %新的加工时间
end
decode_ns.chromesome=chromesome;
[decode_ns]=Unfi_decode(Unfi_initial_time,decode_ns,1,machine_num,fa_num,wo_num_max,unfi_oper_set,job_infor,ope_set,finish_oper_energy,finish_oper,initial_schedule,time);
decode_ns_OB=decode_ns.objectives;
Population_indiv_OB=Population_indiv.objectives;
K=dominate(decode_ns_OB,Population_indiv_OB);
if K==1
    clear Population_indiv
    Population_indiv=decode_ns;
end
end

