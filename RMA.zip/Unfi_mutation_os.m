function [child_os,k1]=Unfi_mutation_os(chromesome,Unfi_oper_num,mutationRate)
%OS层变异（两点变异）

%inputs
% chrom_os: 父代OS层染色体
% chrom_length：染色体长度
% mutationRate：变异概率

%outputs
% child_os：子代OS层染色体
child_os=zeros(1,Unfi_oper_num);
if rand<mutationRate
    number1=unidrnd(Unfi_oper_num);
    number2=unidrnd(Unfi_oper_num);
    while number1==number2
        number2=unidrnd(Unfi_oper_num);
    end
    max_num=max(number1,number2);
    min_num=min(number1,number2);
    chrom1=chromesome(4,min_num+1:max_num);
    chrom2=chromesome(4,max_num+1:Unfi_oper_num);
    L2=size(chrom2,2);
    child_os(1:min_num)=chromesome(4,1:min_num);
    child_os(min_num+1:min_num+L2)=chrom2;
    child_os(min_num+L2+1:Unfi_oper_num)=chrom1;
    k1=1;
else 
    child_os=chromesome(4,1:Unfi_oper_num);
    k1=0;
end
end