function [renew_pop,repeat_size]=Unfi_Renew_pop(Population_home_ns,pop_size,machine_num,job_infor,unfi_oper_set,Obj_num1,fa_num,wo_num_max,Unfi_initial_time,finish_oper_energy,finish_oper,ope_set,initial_schedule,time)
%% 删除重复个体(目标值相同即认定相同)，不足pop_size,随机生成补足
POP=Population_home_ns;
chrom_all=(reshape([POP.objectives],[Obj_num1,pop_size]))';
[C,ia,ic] = unique(chrom_all,'rows');
index=ia';
POP_new=POP(index);
pop_num=size(POP_new,2);
plus_num=pop_size-pop_num;
[pop_plus]=Unfi_initialization(job_infor,plus_num,unfi_oper_set,fa_num,wo_num_max,machine_num,ope_set);
[pop_plus]=Unfi_decode(Unfi_initial_time,pop_plus,plus_num,machine_num,fa_num,wo_num_max,unfi_oper_set,job_infor,ope_set,finish_oper_energy,finish_oper,initial_schedule,time);
renew_pop=POP_new;
renew_pop(pop_num+1:pop_size)=pop_plus;
[renew_pop]=nondominant_sort(renew_pop,pop_size,Obj_num1);
[renew_pop]=Z_crowding_distance(renew_pop,Obj_num1);
repeat_size=plus_num;
end