function MA()
%% read benchmark
dbstop if error
oldpath=cd;      %��ȡ��ǰ����Ŀ¼
folders=dir(oldpath);
folders={folders.name};
folders=setdiff(folders,{'.','..'})';
filenames=folders{1,:};
load (filenames)
filenames_name=filenames(12:end-4);
%% input
y=4;
pop_size=100;
maxgen=100;
crossRate=0.7;
mutationRate=0.4;
NS_rate=0.4;
Obj_num1=2;%%Ŀ����
tic;
Unfi_Populate_first_mean=zeros(maxgen,Obj_num1);
%% population initialization
[pop_st]=initialization(job_infor,job_num,pop_size,all_oper,ope_set,fa_num,wo_num_max,machine_num);
%% decode pop_st
[pop_decode]=decode(pop_st,pop_size,job_num,machine_num,all_oper,fa_num,wo_num_max,ope_set,job_infor);
%% ��֧������
[Population_ns]=nondominant_sort(pop_decode,pop_size,Obj_num1);
[Population_st]=Z_crowding_distance(Population_ns,Obj_num1);
pool_size=round(pop_size/2);
decode_size=pool_size;
%% ��������
for i=1:maxgen
    pool_size=round(pop_size/2);
    tour_size=6;
    Population_parent=tournament_selection(Population_st,pop_size,pool_size,tour_size);  %������ѡ��
    %% ���������(ֻ���������˽������ĸ���)
    [cross_pop]=crossPopulate(Population_parent,pool_size,all_oper,crossRate,ope_set);
    [mut_pop]=mutation_pop(Population_parent,pool_size,job_num,all_oper,mutationRate,job_infor,ope_set);
    m1=size(cross_pop,2);
    m2=size(mut_pop,2);
    pop_evo(1:m1)=cross_pop;
    pop_evo(m1+1:m1+m2)=mut_pop;
    pop_size_new=m1+m2;
    %% �Խ����˽������ĸ�����н���
    [pop_evo]=decode(pop_evo,pop_size_new,job_num,machine_num,all_oper,fa_num,wo_num_max,ope_set,job_infor);
    %% ��Ⱥ���
    [Population_home]=combined_Populate(pop_evo,Population_st,pop_size_new);
    %% ��֧������
    L=size(Population_home,2);
    [Population_home_ns]=nondominant_sort(Population_home,L,Obj_num1);
    [Population_home_ns]=Z_crowding_distance(Population_home_ns,Obj_num1);
    %% ��������
    [Population_home_ns]=neighborhood_search(Population_home_ns,all_oper,L,NS_rate,ope_set,job_infor,job_num,machine_num,fa_num,wo_num_max);
    [Population_home_ns]=nondominant_sort(Population_home_ns,L,Obj_num1);
    [Population_home_ns]=Z_crowding_distance(Population_home_ns,Obj_num1);
    %% ѡ��
    [Population_ch,Population_first]=selectPopulate(Population_home_ns,pop_size);
    %% ȥ��
    [Population_st,repeat_size]=Renew_pop(Population_ch,pop_size,job_num,machine_num,job_infor,all_oper,ope_set,Obj_num1,fa_num,wo_num_max);
    num_first1=size(Population_first,2);
    [Population_first_child]=move_repeat(Population_first,num_first1,Obj_num1);
    clear pop_evo cross_pop non_cross_pop mut_pop non_mut_pop
end
runTime1=toc;
%% ����ȡ��ʱ��
[time,initial_schedule,CanW_num,CanW_num1]=reschedule_time(Population_first_child,y,job_num);
for k=1:5
    tic;
    %% Oders_Classification
    [finish_oper,unfinish_oper,finish_oper_energy,Unfi_initial_time]=Oders_Classification(initial_schedule,fa_num,wo_num_max,machine_num,time,all_oper,CanW_num1);
    [unfi_oper_set,prime_oper_time,pro_total_time,Unfi_oper_num]=TS_setout_procedure(unfinish_oper,job_num,finish_oper,initial_schedule,ope_set,all_oper);
    %% Unfish order population initialization
    [Unfi_pop_st]=Unfi_initialization(job_infor,pop_size,unfi_oper_set,fa_num,wo_num_max,machine_num,ope_set);
    %% Unfish order decode Unfi_pop_st
    [Unfi_pop_decode]=Unfi_decode(Unfi_initial_time,Unfi_pop_st,pop_size,machine_num,fa_num,wo_num_max,unfi_oper_set,job_infor,ope_set,finish_oper_energy,finish_oper,initial_schedule,time);
    %% ��֧������
    [Unfi_Population_ns]=nondominant_sort(Unfi_pop_decode,pop_size,Obj_num1);
    [Unfi_Population_st]=Z_crowding_distance(Unfi_Population_ns,Obj_num1);
    Unfi_pool_size=round(pop_size/2);
    %% ����ȡ����������
    for ii=1:maxgen
        Unfi_pool_size=round(pop_size/2);
        tour_size=6;
        Unfi_Population_parent=Unfi_tournament_selection(Unfi_Population_st,pop_size,Unfi_pool_size,tour_size); %������ѡ��
        %% ���������(ֻ���������˽������ĸ���)
        [Unfi_cross_pop]=Unfi_crossPopulate(Unfi_Population_parent,Unfi_pool_size,Unfi_oper_num,crossRate,unfi_oper_set,ope_set);
        [Unfi_mut_pop]=Unfi_mutation_pop(Unfi_Population_parent,Unfi_pool_size,mutationRate,job_infor,unfi_oper_set,Unfi_oper_num,ope_set);
        m11=size(Unfi_cross_pop,2);
        m22=size(Unfi_mut_pop,2);
        Unfi_pop_evo(1:m11)=Unfi_cross_pop;
        Unfi_pop_evo(m11+1:m11+m22)=Unfi_mut_pop;
        Unfi_pop_size_new=m11+m22;
        %% ��δ�ӹ����������˽������ĸ�����н���
        [Unfi_pop_evo]=Unfi_decode(Unfi_initial_time,Unfi_pop_evo,Unfi_pop_size_new,machine_num,fa_num,wo_num_max,unfi_oper_set,job_infor,ope_set,finish_oper_energy,finish_oper,initial_schedule,time);
        %% ��Ⱥ���
        [Unfi_Population_home]=Unfi_combined_Populate(Unfi_pop_evo,Unfi_Population_st,Unfi_pop_size_new);
        %% ��֧������
        RL=size(Unfi_Population_home,2);
        [Unfi_Population_home_ns]=nondominant_sort(Unfi_Population_home,RL,Obj_num1);
        [Unfi_Population_home_ns]=Z_crowding_distance(Unfi_Population_home_ns,Obj_num1);
        %% ��������
        [Unfi_Population_home_ns]=Unfi_neighborhood_search(Unfi_Population_home_ns,Unfi_oper_num,RL,NS_rate,job_infor,machine_num,fa_num,wo_num_max,time,Unfi_initial_time,unfi_oper_set,finish_oper_energy,finish_oper,ope_set,initial_schedule);
        [Unfi_Population_home_ns]=nondominant_sort(Unfi_Population_home_ns,RL,Obj_num1);
        [Unfi_Population_home_ns]=Z_crowding_distance(Unfi_Population_home_ns,Obj_num1);
        %% ѡ��
        [Unfi_Population_ch,Unfi_Population_first]=selectPopulate(Unfi_Population_home_ns,pop_size);
        %% ȥ��
        [Unfi_Population_st,Unfi_repeat_size]=Unfi_Renew_pop(Unfi_Population_ch,pop_size,machine_num,job_infor,unfi_oper_set,Obj_num1,fa_num,wo_num_max,Unfi_initial_time,finish_oper_energy,finish_oper,ope_set,initial_schedule,time);
        [objective_mean]=Populate_mean(Unfi_Population_first,Obj_num1);
        Unfi_Populate_first_mean(ii,1:Obj_num1)=objective_mean;%%3
        clear Unfi_pop_evo Unfi_cross_pop Unfi_non_cross_pop Unfi_mut_pop Unfi_non_mut_pop
    end
    %% Result
    runTime2=toc;         % ��¼����ʱ��
    runTime=runTime1+runTime2;
    j=mod(k,10);
    i=(k-j)/10;
    filename=strcat('result',char(48+i),char(48+j));
    save(filename);
end

%% ���õ����������ĵ�һǰ�ظ��弯����һ�𣬲����з�֧������
count=5;
num1=0;
runtime_array=zeros(1,5);
for ii=1:count
    jj=mod(ii,10);
    jjj=(ii-jj)/10;
    filename=strcat('result',char(48+jjj),char(48+jj));
    load(filename);
    runtime_array(1,ii)=runTime;
    num_first=size(Unfi_Population_first,2);
    Unfi_Population_all(num1+1:num1+num_first)=Unfi_Population_first;
    num1=num1+num_first;
end
[Unfi_Population_ns_all]=nondominant_sort(Unfi_Population_all,num1,Obj_num1);
[~,index]=find([Unfi_Population_ns_all.rank]==1);
num2=size(index,2);
Unfi_Population_ns_one=Unfi_Population_ns_all(index);
[Unfi_Population_child_all]=move_repeat(Unfi_Population_ns_one,num2,Obj_num1);
filename=strcat('result_all');
save(filename);


% %% ����һǰ�ص�һ����ĸ���ͼ
% best_one=Population_st(1);
% decode_one=Population_st(1).decode;
% [decode_fa]=classification_decode(decode_one,fa_num,wo_num_max);
% best_one.decode_div=decode_fa;
% save('best_pop','decode_fa','job_num','fa_num','wo_num_max','machine_set_wo','machine_num','decode_one','job_infor','Population_st')
% save('best_result2','Populate_first_mean2')
%
% %% ������ͼ
% x=1:150; y1=Populate_first_mean(:,1)'; y2=Populate_first_mean(:,2)';
% figure(1); plot(x,y1,'-*'); figure(2); plot(x,y2,'-s');
end