function [child_os,k1]=mutation_os(chromesome,mutationRate)
%OS�����(����6������������)
os_vector=chromesome(4,:);
all_oper=size(chromesome(4,:),2);
if rand<mutationRate
    number=randperm(all_oper-5,1);
    num_set=[number,number+1,number+2,number+3,number+4,number+5];
    ac=randperm(6);
    num_set1=num_set(ac);
    genes_set=os_vector(num_set1);
    os_vector(num_set)=genes_set;
    child_os=os_vector;
    k1=1;
else 
    child_os=chromesome(4,1:all_oper);
    k1=0;
end
end


