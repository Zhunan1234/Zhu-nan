function  [elites_cp]=Unfi_Criticalpath(Population_indiv,Unfi_oper_num,time,Unfi_initial_time,~,~)
% 根据车间内各机器的负荷，找出关键路径
% 搜索关键工序的终止条件是下道关键工序结束时间等于订单取消时间或者是机器的初始加工加工时间
decode_cp=Population_indiv.decode(1:Unfi_oper_num,:);
makespan=max(decode_cp(:,8));
CT_next=makespan;
num=0;
K=0;
for i=Unfi_oper_num-K:-1:1
    if makespan==CT_next
        [row,~]=find(CT_next==decode_cp(:,8));
        number=size(row,1);
        position=row(randperm(number,1));
        elites_cp(num+1,:)=decode_cp(position,:);      %存关键工序
        if Population_indiv.decode(position,7)==Population_indiv.decode(position,10)
            CT_next=Population_indiv.decode(position,9);   %下道关键工序的结束时间
        else
            CT_next=Population_indiv.decode(position,7);   %下道关键工序的结束时间
        end
        num=num+1;
    else
        [row,~]=find(CT_next==decode_cp(1:Unfi_oper_num,8));
        number=size(row,1);
        if number>1
            comp_inf=decode_cp(row,:);
            [ID,~]=find(comp_inf(:,1)==elites_cp(num,1)); %如果搜索到的下道关键工序结束时间有多个，优先选择上一工序同一工件的工序
            if ~isempty(ID)   %前道工序能够和下道工序接合
                position=row(ID);
                elites_cp(num+1,:)=decode_cp(position,:);      %存关键工序
                Z_fa_rank=decode_cp(position,3);
                Z_wo_rank=decode_cp(position,4);
                Z_ma_rank=decode_cp(position,5);
                ma_time=Unfi_initial_time{Z_fa_rank,Z_wo_rank}(Z_ma_rank,1); %找到当前关键工序所在机器的初始加工时间
                if Population_indiv.decode(position,7)==Population_indiv.decode(position,10)
                    CT_next=Population_indiv.decode(position,9);   %下道关键工序的结束时间
                else
                    CT_next=Population_indiv.decode(position,7);   %下道关键工序的结束时间
                end
                num=num+1;
                if CT_next==time   %如果下道关键工序的结束时间为紧急插单时刻，则循环终止
                    break
                elseif CT_next==ma_time    %如果下道关键工序的结束时间不为紧急插单时刻而为机器的初始加工时刻，则循环也终止
                    break
                end
            else %机器的前道工序与下道工序接合；2.机器的前道工序与下道工序不结合
                fa_rank=elites_cp(num,3);
                wo_rank=elites_cp(num,4);
                ma_rank=elites_cp(num,5);
                NUM=size(comp_inf,1);
                comp_inf1=comp_inf(1:NUM,3:5);
                ID=ismember(comp_inf1,[fa_rank,wo_rank,ma_rank],'rows');
                [ID1,~]=find(ID==1);
                if ~isempty(ID1) %如果机器的前道工序与下道工序接合
                    position=row(ID1,1);
                else             %如果机器的前道工序与下道工序不接合
                    position=row(randperm(number,1));
                end
                elites_cp(num+1,:)=decode_cp(position,:);      %存关键工序
                Z_fa_rank=decode_cp(position,3);
                Z_wo_rank=decode_cp(position,4);
                Z_ma_rank=decode_cp(position,5);
                ma_time=Unfi_initial_time{Z_fa_rank,Z_wo_rank}(Z_ma_rank,1); %找到当前关键工序所在机器的初始加工时间
                if Population_indiv.decode(position,7)==Population_indiv.decode(position,10)
                    CT_next=Population_indiv.decode(position,9);   %下道关键工序的结束时间
                else
                    CT_next=Population_indiv.decode(position,7);   %下道关键工序的结束时间
                end
                num=num+1;
                if CT_next==time
                    break
                elseif CT_next==ma_time
                    break
                end
            end
        elseif number==1
            position=row(1);
            elites_cp(num+1,:)=decode_cp(position,:);      %存关键工序
            Z_fa_rank=decode_cp(position,3);
            Z_wo_rank=decode_cp(position,4);
            Z_ma_rank=decode_cp(position,5);
            ma_time=Unfi_initial_time{Z_fa_rank,Z_wo_rank}(Z_ma_rank,1); %找到当前关键工序所在机器的初始加工时间
            if Population_indiv.decode(position,7)==Population_indiv.decode(position,10)
                CT_next=Population_indiv.decode(position,9);   %下道关键工序的结束时间
            else
                CT_next=Population_indiv.decode(position,7);   %下道关键工序的结束时间
            end
            num=num+1;
            if CT_next==time
                break
            elseif CT_next==ma_time
                break
            end
        else
            break
        end
        K=Unfi_oper_num-position;
    end
end
end
