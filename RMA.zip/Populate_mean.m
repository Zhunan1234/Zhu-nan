function [objective_mean]=Populate_mean(Population_first,Obj_num)
%���ڵ�һǰ�صĸ����ÿ��Ŀ��ȡƽ��ֵ
count=size(Population_first,2);
Populate_objective=zeros(count,Obj_num);
objective_mean=zeros(1,Obj_num);
for i=1:count
    Populate_objective(i,:)=Population_first(i).objectives(1:Obj_num);
end
objective_mean(1,1)=round(sum(Populate_objective(1:count,1))/count);
objective_mean(1,2)=round(sum(Populate_objective(1:count,2))/count);
end