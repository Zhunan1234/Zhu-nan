function [Population_home]=combined_Populate(pop_evo,Population_st,pop_size_new)
%�ϲ���Ⱥ
pop_size1=size(Population_st,2);
Population_home=Population_st;
size1=pop_size1+pop_size_new;
Population_home(pop_size1+1:size1)=pop_evo;
end