function [child1,child2,k1]=Unfi_crossover_os(chrom1,chrom2,all_ope1,all_ope2,Unfi_oper_num,crossRate,unfi_oper_set,ope_set)
child1=zeros(1,all_ope1);    %generate two offsetings
child2=zeros(1,all_ope2);
chrom1_os=chrom1(1,1:all_ope1);                   %OS层
chrom2_os=chrom2(1,1:all_ope2);                   %OS层

if rand<crossRate
    %% OS层交叉
    kk=randperm(Unfi_oper_num,2);   %随机取一段父代个体基因片段
    max_pos=max(kk);
    min_pos=min(kk);
    chrom1_os_vector=chrom1_os;
    chrom2_os_vector=chrom2_os;
    OS1_EX=chrom1_os(min_pos:max_pos);
    OS1_EX_re=unique(chrom1_os(min_pos:max_pos));   %去重排序
    m1=size(OS1_EX_re,2);
    p_set=[];
    ad_set=[];
    max_pos_re=max_pos;  %原随机选取工序最大值
    %% 识别该区间1内所有基因对应的工序
    for ii=1:m1
        id=[];
        job=OS1_EX_re(ii);
        [~,c0]=find(ope_set(1,:)==job);
        oper=ope_set(2,c0);
        c=1:oper;
        c1=sort(c,'descend');
        [~,id]=find(OS1_EX_re(ii)==OS1_EX(1,:));  %找到工件在所选基因片段中的位置
        [~,IN,~]=find(OS1_EX(1,id));
        ID=size(id,2);
        c2=c1(1:ID);
        c3=sort(c2);     %工序个数排列（1,2,3...)
        OS1_EX(2,id)=c3;  %各个工件额对应工序号
        op1=find(unfi_oper_set(1,:)==OS1_EX_re(ii));
        op_num=size(op1,2);
        [~,IM]=find(IN(1,:)>op_num);  %找到工件对应工序号大于正常工序数的位置
        ad_num=[];
        if ~isempty(IM)
            MI=size(IM,2);   %工序号大于正常工序数的工序个数
            OS1_EX(:,id(IM))=[];     %将所选基因片段中工序号大于正常工序数的工序置空
            c3(:,IM)=[];     %将工件对应工序号大于正常工序数的工序置空
            max_pos=max_pos-MI;  %置空后的最大随机基因片段位置
            ad_num=repmat(OS1_EX_re(ii),1,MI); %删除工序数量集合
        end
        ad_set=[ad_set,ad_num];  %删除的工序集
        job_rank=OS1_EX_re(ii);
        oper_set=IN;
        num=size(IN,2);   %对应工件的工序个数
        p_rank=zeros(1,num);
        for j=1:num
            [~,IP]=find(job_rank==chrom2_os);   %在父辈P2中找到工件工序的对应位置
            p_rank(1,j)=IP(oper_set(j));     %各个工序在父辈P2染色体中的对应位置
        end
        p_set=[p_set,p_rank];
    end
    p_set=sort(p_set);   %将各个位置进行排序
    aaa=chrom2_os_vector(p_set);    %按照P2中各个基因片段的顺序进行排列
    num_set=[min_pos:max_pos];
    num=size(num_set,2);
    zn=randperm(num);
    bbb=aaa(zn);
    chrom1_os_vector(min_pos:max_pos)=bbb;
    ad_set=ad_set(randperm(size(ad_set,2))); %删除工序集乱序排列
    chrom11=chrom1_os_vector(1:max_pos);
    chrom22=ad_set;  %删除工序集
    chrom33=chrom1_os_vector(max_pos_re+1:end);
    child1=[chrom11,chrom22,chrom33];
    ccc=OS1_EX(1,:);
    zzz=ccc(zn);
    chrom2_os_vector(p_set)=zzz;   %将父辈P1中所取的基因片段放到P2中对应的位置，即为子代C2
    child2=chrom2_os_vector;
    k1=1;
else
    k1=0;
end
end