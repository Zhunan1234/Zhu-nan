function [Unfi_cross_pop]=Unfi_crossPopulate(Unfi_Population_parent,Unfi_pool_size,Unfi_oper_num,crossRate,unfi_oper_set,ope_set)
%自定义Subtour Exchange Crossover（SECX交叉方法）
cross_pop1(1:Unfi_pool_size*2)=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'work_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
num1=1;
for i=1:Unfi_pool_size
    number1=unidrnd(Unfi_pool_size);
    number2=unidrnd(Unfi_pool_size);
    while number1==number2
        number2=unidrnd(Unfi_pool_size);
    end
    all_ope1=size(Unfi_Population_parent(number1).chromesome,2);     %每次随机选取的染色体长度
    all_ope2=size(Unfi_Population_parent(number2).chromesome,2);
    chrom1=Unfi_Population_parent(number1).chromesome(4,1:all_ope1);     %随机取两个父代个体
    chrom2=Unfi_Population_parent(number2).chromesome(4,1:all_ope2);
    [child1,child2,k1]=Unfi_crossover_os(chrom1,chrom2,all_ope1,all_ope2,Unfi_oper_num,crossRate,unfi_oper_set,ope_set);
    if k1==1                          %% 如果进行了交叉
    cross_pop1(num1).chromesome=Unfi_Population_parent(number1).chromesome;
    cross_pop1(num1).chromesome(4,1:all_ope1)=child1;
    cross_pop1(num1+1).chromesome=Unfi_Population_parent(number2).chromesome;
    cross_pop1(num1+1).chromesome(4,1:all_ope2)=child2;
    num1=num1+2;
    end
end
Unfi_cross_pop=cross_pop1(1:num1-1);  %发生交叉的父代个体数
end