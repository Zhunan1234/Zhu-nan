function [Unfi_Population_home_ns]=Unfi_neighborhood_search(Unfi_Population_home_ns,Unfi_oper_num,RL,NS_rate,job_infor,machine_num,fa_num,wo_num_max,time,Unfi_initial_time,unfi_oper_set,finish_oper_energy,finish_oper,ope_set,initial_schedule)
%邻域搜索结构

%inputs:
%Population_ns;带有解码和排序信息的种群

%outputs:
%Population_ns:邻域搜索更新后的种群
%critical_oper:构建的关键工序的结构数组
%当前工序信息——chrome_position：染色体位置；job_rank：所属工件号；satge_rank：所属工序号；ma_rank：机器选择；wo_rank：工人选择；oper_time：加工时间（包括开始与结束）
%predecessor_stage：前继工序信息，与上同
%predecessor_ma：机器上的前继工序信息，与上同
for i=1:ceil(RL*NS_rate) %ceil:向上取整
    Unfi_Population_indiv=Unfi_Population_home_ns(i);
    [elites_cp]=Unfi_Criticalpath(Unfi_Population_indiv,Unfi_oper_num,time,Unfi_initial_time,fa_num,wo_num_max);
    RL=size(elites_cp,1);
    [Unfi_Population_indiv]=Unfi_VFWM_search2(Unfi_initial_time,Unfi_Population_indiv,elites_cp,RL,job_infor,machine_num,fa_num,wo_num_max,unfi_oper_set,finish_oper_energy,finish_oper,ope_set,initial_schedule,time);
    Unfi_Population_home_ns(i)=Unfi_Population_indiv;
    Unfi_Population_home_ns(i).critical_path=elites_cp;
end
end