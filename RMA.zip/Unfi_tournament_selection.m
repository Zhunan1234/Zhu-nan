function Unfi_Population_parent=Unfi_tournament_selection(Unfi_Population_st,pop_size,Unfi_pool_size,tour_size)
%锦标赛选择
% function tournament_selection1(Population_st,pool_size,tour_size) is the
% selection policy for selecting the individuals for the mating pool. The
% selection is based on tournament selection. Argument 'Population_st' is the
% current generation population from which the individuals are selected to
% form a mating pool of size 'pool_size' after performing tournament
% selection, with size of the tournament being 'tour_size'. By varying the
% tournament size the selection pressure can be adjusted.
%函数tournament_selection1(Population_st,pool_size,tour_size)是为交
%配池选择个体的选择策略。选择是基于锦标赛的选择。参数'Population_st'是
%当前的一代人口，在进行了锦标赛选择后，从这些个体中选出来组成一个大小为'pool_size'
%的交配池，锦标赛的大小为'tour_size'。通过改变比赛规模，选择压力可以调整。
Unfi_Population_parent(1:Unfi_pool_size)=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'work_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
for i=1:Unfi_pool_size
    candidate=zeros(3,tour_size);              %用来存储随机选择的两个个体的编号
    %candidate:第一行——选择个体的编号
    %第二行——对应个体的前沿序号
    %第三行——对应个体的拥挤距离
    candidate(1,:)=randperm(pop_size,tour_size);
    for j=1:tour_size
        candidate(2,j)=Unfi_Population_st(candidate(1,j)).rank;
        candidate(3,j)=Unfi_Population_st(candidate(1,j)).crowded_distance;
    end
    min_candidate=find(candidate(2,:)==min(candidate(2,:)));
    if size(min_candidate,2)~=1
        max_candidate=find(candidate(3,min_candidate)==max(candidate(3,min_candidate)));
        if size(max_candidate,2)~=1
            max_candidate = max_candidate(1);
        end
        Unfi_Population_parent(i)=Unfi_Population_st(candidate(1,min_candidate(max_candidate)));
    else
        Unfi_Population_parent(i)=Unfi_Population_st(candidate(1,min_candidate(1)));
    end
end
end
