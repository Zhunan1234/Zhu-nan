function[time,initial_schedule,CanW_num,CanW_num1]=reschedule_time(Population_first_child,y,job_num)
initial_schedule(1)=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
m=size(Population_first_child,2);
for i=1:m
    span(i,1)=Population_first_child(i).objectives(1);
end
v=min(span);
n=size(v,1);
if n==1
    r=n;
    time=randperm(v(r),1);
    while time<v/3||time>2*v/3 %条件成立则执行循环语句
        time=randperm(v,1);
        time=time+0;
    end
else
    r=randperm(n,1);
    time=randperm(v(r),1);
    while time<r/3||time>2*r/3
        time=randperm(v,1);
        time=time+0;
    end
end
[ID,~]=find(span==v(r));
ID1=size(ID,1);
if ID1==1
   initial_schedule(1,:)=Population_first_child(ID);
else
   initial_schedule(1,:)=Population_first_child(ID(1)); 
clear span
end
%%随机取消的工件
n=y;  %随机取消的工件数
A=1:job_num;
random_num=A(randperm(numel(A),n));
CanW_num=sort(random_num);
CanW_num1=CanW_num;