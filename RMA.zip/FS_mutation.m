function [chrom_fs]=FS_mutation(chrom_fs,job_num,factory_num,oper_infor)
%% �������һ���������ҵ������ڵĹ���������
avai_f=1:factory_num;
mut_job=randperm(job_num,2);
m=size(mut_job,2);
for j=1:m
    if mut_job(1,j)==1
        sum_pre=0;
    else
        sum_pre=sum(oper_infor(2,1:mut_job(1,j)-1));
    end
    f_rank=chrom_fs(1,sum_pre+1);
    [~,in]=find(avai_f==f_rank);
    avai_f(in)=[];
    k=size(avai_f,2);
    w=randperm(k);
    f_rank=avai_f(w);
    f_vector=repmat(f_rank,1,oper_infor(2,mut_job(1,j)));
    chrom_fs(1,sum_pre+1:sum_pre+oper_infor(2,mut_job(1,j)))=f_vector;
    avai_f=1:factory_num;
end
end