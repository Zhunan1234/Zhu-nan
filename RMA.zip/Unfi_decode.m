function[Unfi_pop_decode]=Unfi_decode(Unfi_initial_time,Unfi_pop_st,pop_size,machine_num,fa_num,wo_num_max,unfi_oper_set,job_infor,ope_set,finish_oper_energy,finish_oper,initial_schedule,time)
%% decode信息包括：
%第一列：工件号
%第二列：工序号
%第三列：工厂号
%第四列：车间号
%第五列：机器号
%第六列：加工时间
%第七列：开始加工时间
%第八列：结束时间
%第九列：移动操作的开始时间
%第十列：移动操作的结束时间
%第十一列：表示每次移动的时间
%第十二列：加工单位能耗
%第十三列：加工成本
%% 机器加工时间集合
%第一列：工件号
%第二列：工序号
%第三列：开始时间
%第四列：结束时间
%% pro_time中
%第一行：开始时间
%第二行：结束时间
%% 定义跨工厂运输时间为10，跨车间运输时间为5
%% 目标值：最大完工时间和累计移动时间
move_time_set=[0,5,10,20];
Unfi_pop_decode=Unfi_pop_st;
P_move=10;            %% 工件移动消耗的单位能耗
Unfi_oper_num=size(unfi_oper_set,2);
fin_oper_num=size(finish_oper,1);
a=unfi_oper_set(1,:);
job_set=unique(a);
job_zz=size(job_set,2);
pre_decode=initial_schedule.decode;
for i=1:pop_size
    W_consume=0;
    Unfi_chrom_decode=zeros(Unfi_oper_num,13);
    Unfi_mach_load=cell(fa_num,wo_num_max);   %存储每次解码的机器信息
    Unfi_pro_time_oper=zeros(2,Unfi_oper_num);      %存储每道工序的加工时间
    Unfi_work_load=cell(fa_num,wo_num_max);   %储存车间负载
    Unfi_sub_mach_load=cell(machine_num,4);
    Unfi_chromesome=Unfi_pop_decode(i).chromesome;
    for k=1:fa_num
        for k1=1:wo_num_max
            Unfi_mach_load{k,k1}=Unfi_sub_mach_load;
        end
    end
    Unfi_chrom_fs=Unfi_pop_decode(i).chromesome(1,1:Unfi_oper_num);     %读取工厂染色体信息
    Unfi_chrom_ws=Unfi_pop_decode(i).chromesome(2,1:Unfi_oper_num);     %读取车间染色体信息
    Unfi_chrom_ms=Unfi_pop_decode(i).chromesome(3,1:Unfi_oper_num);     %读取机器染色体信息
    Unfi_chrom_os=Unfi_pop_decode(i).chromesome(4,1:Unfi_oper_num);     %读取工件染色体信息
    Unfi_chrom_ps=Unfi_pop_decode(i).chromesome(5,1:Unfi_oper_num);     %读取加工时间染色体信息
    Unfi_chrom_cs=Unfi_pop_decode(i).chromesome(6,1:Unfi_oper_num);     %读取加工成本染色体信息
    %% 读取工件相关信息（初始化的时候，染色体的工序并没有和其加工工厂、车间、机器、加工时间一一对应，这一过程就是将其对应起来）
    num=0;
    load1=cell(machine_num,4);
    for j=1:job_zz
        job_rank=job_set(1,j);
        [~,IP]=find(Unfi_chrom_os==job_rank);                              %找到工件每道工序在染色体中的位置
        num_stage=size(IP,2);
        [~,~,ID]=find(Unfi_chrom_os(IP)); %找到工件每道工序在染色体中的列序列以及数值，工件号
        [~,IV]=find(unfi_oper_set(1,:)==job_rank);
        IO=unfi_oper_set(2,IV);
        for ii=1:num_stage
            Unfi_chrom_decode(IP(1,ii),1)=ID(1,ii);                 %存工件号
            Unfi_chrom_decode(IP(1,ii),2)=IO(1,ii);                 %存工序号
            Unfi_chrom_decode(IP(1,ii),3)=Unfi_chrom_fs(1,num+ii);  %存工厂号
            Unfi_chrom_decode(IP(1,ii),4)=Unfi_chrom_ws(1,num+ii);  %存车间号
            Unfi_chrom_decode(IP(1,ii),5)=Unfi_chrom_ms(1,num+ii);  %存机器号
            Unfi_chrom_decode(IP(1,ii),6)=Unfi_chrom_ps(1,num+ii);  %存加工时间
            Unfi_chrom_decode(IP(1,ii),7)=0;                        %开始时间
            Unfi_chrom_decode(IP(1,ii),8)=0;                        %结束时间
            Unfi_chrom_decode(IP(1,ii),13)=Unfi_chrom_cs(1,num+ii);           %存加工成本
        end
        num=num_stage+num;
    end
    %% 开始解码
    for j=1:Unfi_oper_num
        job_rank=Unfi_chrom_decode(j,1);                 %读取工件号
        ope_rank=Unfi_chrom_decode(j,2);                 %读取工序号
        fa_rank=Unfi_chrom_decode(j,3);                  %读取工厂号
        wo_rank=Unfi_chrom_decode(j,4);                  %读取车间号
        ma_rank=Unfi_chrom_decode(j,5);                  %读取机器号
        pro_time=Unfi_chrom_decode(j,6);                 %读取加工时间
        %%读取单个工序的单位能耗
        NO=sum(ope_set(2,1:job_rank-1))+ope_rank;
        %%找到工厂的位置
        [ID1,~]=find(job_infor(NO).fa_rank==fa_rank);
        %%找到车间的位置
        [~,ID2]=find(job_infor(NO).wo_rank(ID1,:)==wo_rank);
        %%找到机器的位置
        MA_SET=job_infor(NO).mach_rank{ID1,ID2};
        [~,ID3]=find(MA_SET==ma_rank);
        power_set=job_infor(NO).power{ID1,ID2};
        power_one=power_set(1,ID3);     %读取当前工序的单位能耗
        Unfi_chrom_decode(j,12)=power_one;  %将工序单位能耗存入第12行
        initial_time=Unfi_initial_time{fa_rank,wo_rank}(ma_rank,1); %读取剩余工序在机器上的初始加工时间
        [~,lo]=find(unfi_oper_set(1,:)==job_rank);
        ope=unfi_oper_set(2,lo);
        z=find(ope==ope_rank);
        if ope_rank==1
           CT_pre=0;
           VECTOR(1,1)=CT_pre;           %%用于后续插入操作
           VECTOR(1,2)=inf;
           W_move=0;
%         if ope_rank==1                              %读取上一道工序的结束时间
%             [f4,~]=find(pre_decode(:,1)==job_rank);
%             [f5,~]=find(pre_decode(f4,2)==ope_rank);
%             gg=f4(f5);
%             pre_fa=pre_decode(gg,3);
%             pre_wo=pre_decode(gg,4);
%             pre_ma=pre_decode(gg,5);
%             if pre_fa==fa_rank
%                 if pre_wo==wo_rank
%                     if pre_ma==ma_rank
%                        m=1;   %第二阶段该工序不用移动
%                     else
%                         m=2;   %该工序在第二阶段进行机器间的移动
%                     end
%                 else
%                     m=3;   %该工序在第二阶段进行车间的移动
%                 end
%             else
%                 m=4;  %该工序在第二阶段进行工厂的移动
%             end
%             coo=m;
%             move_time=move_time_set(coo);
%             pre1=time+move_time;
%             pre2=initial_time;
%             Pre=max(pre1,pre2);  %起始时间为前道工序完成时间与机器初始加工时间中的最大值
%             CT_pre=Pre;
%             VECTOR(1,1)=CT_pre;           %%用于后续插入操作
%             VECTOR(1,2)=inf;
%             W_move=move_time*P_move;
%             if move_time>0
%                 if initial_time-time>move_time
%                 move_ST=initial_time-move_time;               %记录移动开始时间
%                 move_CT=initial_time;                          %记录移动结束时间
%                 else
%                     move_ST=time; 
%                     move_CT=time+move_time;
%                 end
%                 Unfi_chrom_decode(j,9)=move_ST;
%                 Unfi_chrom_decode(j,10)=move_CT;
%                 Unfi_chrom_decode(j,11)=move_time;   %%用于计算移动的时间
%             end
        elseif z==1         %读取上一道工序的结束时间
            [f,~]=find(finish_oper(:,1)==job_rank);
            [f1,~]=find(finish_oper(f,2)==ope_rank-1);
            ff=f(f1);
            CT_pre=finish_oper(ff,8);
%             [f2,~]=find(pre_decode(:,1)==job_rank);
%             [f3,~]=find(pre_decode(f2,2)==ope_rank);
%             fff=f2(f3);
%             pre_fa=pre_decode(fff,3);
%             pre_wo=pre_decode(fff,4);
%             pre_ma=pre_decode(fff,5);
            pre_fa=finish_oper(ff,3);
            pre_wo=finish_oper(ff,4);
            pre_ma=finish_oper(ff,5);
            if pre_fa==fa_rank
                if pre_wo==wo_rank
                    if pre_ma==ma_rank
                       m=1;   %第二阶段该工序不用移动
                    else
                        m=2;   %该工序在第二阶段进行机器间的移动
                    end
                else
                    m=3;   %该工序在第二阶段进行车间的移动
                end
            else
                m=4;  %该工序在第二阶段进行工厂的移动
            end
            coo=m;
            move_time=move_time_set(coo);
            pre1=CT_pre+move_time;
            pre2=initial_time;
            Pre=max(pre1,pre2);  %起始时间为前道工序完成时间与机器初始加工时间中的最大值
            CT_pre=Pre;
            VECTOR(1,1)=CT_pre;           %%用于后续插入操作
            VECTOR(1,2)=inf;
            W_move=move_time*P_move;
            if move_time>0
                move_ST=CT_pre-move_time;                %记录移动开始时间
                move_CT=CT_pre;                          %记录移动结束时间
                Unfi_chrom_decode(j,9)=move_ST;
                Unfi_chrom_decode(j,10)=move_CT;
                Unfi_chrom_decode(j,11)=move_time;   %%用于计算移动的时间
            end
        else
            [~,IP1]=find(Unfi_chrom_os==job_rank);
            CT_pre=Unfi_chrom_decode(IP1(z-1),8);
            pre_fa_rank=Unfi_chrom_decode(IP1(z-1),3);
            pre_wo_rank=Unfi_chrom_decode(IP1(z-1),4);
            pre_ma_rank=Unfi_chrom_decode(IP1(z-1),5);
            if pre_fa_rank==fa_rank
                if pre_wo_rank==wo_rank
                    if pre_ma_rank==ma_rank
                       m=1;   %第二阶段该工序不用移动
                    else
                        m=2;   %该工序在第二阶段进行机器间的移动
                    end
                else
                    m=3;
                end
            else
                m=4;
            end
            coo=m;
            move_time=move_time_set(coo);
            W_move=move_time*P_move;
            pre1=CT_pre+move_time;
            pre2=initial_time;
            Pre=max(pre1,pre2);  %起始时间为前道工序完成时间与机器初始加工时间中的最大值
            CT_pre=Pre;
            VECTOR(1,1)=CT_pre;           %%用于后续插入操作
            VECTOR(1,2)=inf;
            if move_time>0
                move_ST=CT_pre-move_time;                %记录移动开始时间
                move_CT=CT_pre;                          %记录移动结束时间
                Unfi_chrom_decode(j,9)=move_ST;
                Unfi_chrom_decode(j,10)=move_CT;
                Unfi_chrom_decode(j,11)=move_time;   %%用于计算移动的时间
            end
        end
        W_consume=W_consume+pro_time*power_one+W_move;   %% 累计工件消耗的总能耗
        wo_load=Unfi_mach_load{fa_rank,wo_rank};
        if isempty(wo_load{ma_rank,1})      %读取机器的空闲时间
            load1=Unfi_mach_load{fa_rank,wo_rank};
            ST_ma=CT_pre;
            Unfi_chrom_decode(j,7)=ST_ma;                 %存储工序开始加工时间
            Unfi_pro_time_oper(1,j)=ST_ma;
            Unfi_chrom_decode(j,8)=ST_ma+pro_time;        %存储工序完成加工时间
            Unfi_pro_time_oper(2,j)=ST_ma+pro_time;
            load1{ma_rank,1}(1,1)=job_rank;
            load1{ma_rank,2}(1,1)=ope_rank;
            load1{ma_rank,3}(1,1)=ST_ma;          %更新机器加工起始时间
            load1{ma_rank,4}(1,1)=ST_ma+pro_time;
            Unfi_mach_load{fa_rank,wo_rank}=load1;
        else
            %%判断是否需要插入操作
            %step 1 找出所有空隙
            %step 2 找出空隙中满足约束的区间进行插入(要特别注意)
            load2=Unfi_mach_load{fa_rank,wo_rank};
            col_ma=size(load2{ma_rank,1},2);
            for m=1:col_ma %%判断机器上已加工完的工序前面能否插入当前加工工序，依次找到空闲时间段
                if m==1 %%判断目前所加工工序能否插入第一个已加工工序前面，为此找到空闲时间段
                    CT_pre_ma=initial_time;                                %%取机器的上道工序的完成时间
                    ST_ma_now=load2{ma_rank,3}(1,m);      %%取机器的当前工序的完成时间（已排列的）
                else
                    CT_pre_ma=load2{ma_rank,4}(1,m-1);
                    ST_ma_now=load2{ma_rank,3}(1,m);
                end
                VECTOR(2,1)=CT_pre_ma;
                VECTOR(2,2)=ST_ma_now;
                C1=max(VECTOR(:,1));
                interval(1,m)=C1;       %如果可以插入，二者的最大值作为插入后的开始时间
                C2=min(VECTOR(:,2));
                interval(2,m)=C2;
                interval(3,m)=C2-C1;
            end
            [~,avail]=find(interval(3,:)>=pro_time);
            if ~isempty(avail)
                posi=avail(1);              %以C1作为开始时间
                ST_ma=interval(1,posi);
            else
                CT_oper_pre=CT_pre;  %%本工件前道的结束时间
                CT_mach_pre=max(load2{ma_rank,4});  %%机器前道工序的完工时间
                ST_ma=max(CT_oper_pre,CT_mach_pre); %%取最大值即为本道工序的开始时间
            end
            clear interval
            %%更新插入后的信息
            Unfi_chrom_decode(j,7)=ST_ma;
            Unfi_pro_time_oper(1,j)=ST_ma;
            Unfi_chrom_decode(j,8)=ST_ma+pro_time;
            Unfi_pro_time_oper(2,j)=ST_ma+pro_time;
            load2{ma_rank,1}(1,col_ma+1)=job_rank;
            load2{ma_rank,2}(1,col_ma+1)=ope_rank;
            load2{ma_rank,3}(1,col_ma+1)=ST_ma;
            load2{ma_rank,4}(1,col_ma+1)=ST_ma+pro_time;
            [load2{ma_rank,3},index]=sort(load2{ma_rank,3});
            load2{ma_rank,4}=load2{ma_rank,4}(index);
            load2{ma_rank,1}=load2{ma_rank,1}(index);
            load2{ma_rank,2}=load2{ma_rank,2}(index);
            Unfi_mach_load{fa_rank,wo_rank}=load2;
            clear load2
        end
        clear load1
    end
    %% 计算未加工工序的车间负载
    for fa=1:fa_num
        for wo=1:wo_num_max
            load_wo=Unfi_mach_load{fa,wo};
            if ~isempty(load_wo)
                for ma=1:machine_num
                    ma_load=load_wo{ma,4};
                    if ~isempty(ma_load)
                        load_all(ma)=max(ma_load);
                    else
                        load_all(ma)=0;
                    end
                end
            end
            max_wo_load1=max(load_all);
            max_wo_load=Unfi_work_load{fa,wo};
            max_wo_load(2)=max_wo_load1;
            Unfi_work_load{fa,wo}=max_wo_load;
        end
    end
    %% 将初始订单已完工工序解码信息与重调度窗口完工工序解码信息合并
    ZN=size(Unfi_chrom_decode,1);
    Unfi_chrom_decode(ZN+1:fin_oper_num+Unfi_oper_num,:)=finish_oper;
    %% 计算工厂、车间、机器负荷，从而得出makespan
    for f=1:fa_num
        for w=1:wo_num_max
            load=Unfi_mach_load{f,w};
            if ~isempty(load)
                for m=1:machine_num
                    load_ma=load{m,4};
                    if ~isempty(load_ma)
                        load_all_w(m)=max(load_ma);
                    else
                        load_all_w(m)=0;
                    end
                end
            end
            wo_load1(f,w)=max(load_all_w);
        end
        fa_load(f)=max(wo_load1(f,:));
    end
    %% 求解3个目标值：makespan
    makespan=max(fa_load);                  %取最大完工时间
    Unfi_pop_decode(i).objectives(1,1)=makespan;    %最大完工时间目标
    %         move_time_all=sum(chrom_decode(:,11));
    %         pop_decode(i).objectives(1,2)=move_time_all;   %总移动时间
    Unfi_pop_decode(i).objectives(1,2)=W_consume+finish_oper_energy;      %总能耗
    %% 解码个体的信息存储
    Unfi_pop_decode(i).decode=Unfi_chrom_decode;
    %% 机器和工人加工信息的存储
    Unfi_pop_decode(i).mach_load=Unfi_mach_load;
    %% 每个车间的负载
    Unfi_pop_decode(i).work_load=Unfi_work_load;
    %% 每个工厂的负荷
    Unfi_pop_decode(i).factory_load=fa_load;
    %% 每道工序的加工时间
    Unfi_pop_decode(i).pro_time=Unfi_pro_time_oper;
    clear mach_load pro_time_oper
end
end














