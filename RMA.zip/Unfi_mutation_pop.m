function [Unfi_mut_pop]=Unfi_mutation_pop(Unfi_Population_parent,Unfi_pool_size,mutationRate,job_infor,unfi_oper_set,Unfi_oper_num,ope_set)
% 变异产生的新个体

%inputs
% Population_st;c初始化的种群
% pop_size：种群规模
% job_num;工件数
% all_oper;染色体长度
% mutationRate;变异概率
%ope_set:工件的工序信息
%job_infor：各工序可处理的情况

%outputs
% mutationPopulation:变异获得种群
mut_pop1(1:Unfi_pool_size)=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'work_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
num1=1;
mutationPopulation=Unfi_Population_parent;
for i=1:Unfi_pool_size
    chromesome=mutationPopulation(i).chromesome;
    a=unfi_oper_set(1,:);
    job_set=unique(a);
    job_zz=size(job_set,2);
    for j=1:job_zz
        job_rank=job_set(1,j);
        [~,ic]=find(chromesome(4,:)==job_rank);
        [~,in]=find(unfi_oper_set(1,:)==job_rank);
        id=unfi_oper_set(2,in);
        chromesome(7,ic)=id;                %%就工序号对应到染色体中，便于后续的工厂变异识别工件和工序,放第六行
    end
    %% OS层变异   工件工序变异
    [child_os,k1]=Unfi_mutation_os(chromesome,Unfi_oper_num,mutationRate);
    %% 其他层次变异
    [child,k2]=Unfi_mutation_others(chromesome,mutationRate,unfi_oper_set,job_infor,ope_set);
    child(4,:)=child_os;
    chromesome=child;
    if k1+k2>0
        mut_pop1(num1).chromesome=chromesome;
        num1=num1+1;
    end
end
Unfi_mut_pop=mut_pop1(1:num1-1);
end