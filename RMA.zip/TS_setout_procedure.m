function[unfi_oper_set,prime_oper_time,pro_total_time,Unfi_oper_num]=TS_setout_procedure(unfinish_oper,job_num,finish_oper,initial_schedule,ope_set,all_oper)
%1、找到未加工工序工件号，便于后期解码时寻找工件工序信息；
%2、找到原始调度解中各工件的加工完成时间；
%3、找到已加工工序的开始及结束时间，便于后期未加工工件调度时储存其开始及结束时间；
primeval_pro_time=initial_schedule.pro_time;
primeval_decode=initial_schedule.decode;
k=size(unfinish_oper,1);
unfi_oper_set=zeros(2,k);%存储未加工工件的工序
prime_oper_time=zeros(2,all_oper); %存储原始调度的各工序加工时间
pro_total_time=cell(job_num,1);%存储工序的开始及结束时间（按顺序排列）
Unfi_oper_num=size(unfi_oper_set,2);
num=0;
num1=0;
for i=1:job_num
    oper_max=ope_set(2,i);
    %%找到未加工的工件的工序
    [m,~]=find(unfinish_oper(:,1)==i);
    n=size(m,1);
    unfi_oper_set(1,num+1:num+n)=i;
    for j=1:n
        unfi_oper_set(2,num+j)=unfinish_oper(m(j),2);
    end
    num=num+n;
    %%找到原始调度解的各工件工序的加工时间
    [IP,~]=find(primeval_decode(:,1)==i);
    prime_oper_time(:,1+num1:num1+oper_max)=(primeval_pro_time(:,IP'));
    num1=num1+oper_max;
    %%找到已加工工序的开始及结束时间
    total_time=zeros(2,oper_max);
    [index_num,~]=find(finish_oper(:,1)==i);
    oper_num=size(index_num,1);
    for jj=1:oper_num
        oper_stage=finish_oper(index_num(jj),2);
        total_time(1,oper_stage)=finish_oper(index_num(jj),7);
        total_time(2,oper_stage)=finish_oper(index_num(jj),8);
    end
    total_time1=num2cell(total_time,[1,2]); %将double转换为cell数组
    pro_total_time(i,1)=total_time1;
end
clear total_time primeval_pro_time primeval_decode oper_max num num1 IP index_num oper_num oper_stage total_time1 i m j jj 
end