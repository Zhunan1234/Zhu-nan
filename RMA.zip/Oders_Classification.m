function[finish_oper,unfinish_oper,finish_oper_energy,Unfi_initial_time]=Oders_Classification(initial_schedule,fa_num,wo_num_max,machine_num,time,all_oper,CanW_num1)
%% 甄别订单取消时刻原始调度工序的类型：已加工完的工序；正在加工的工序；未加工工序。记录订单取消时刻每台机器的最大加工时间，并计算已加工工序的能耗
%找出订单取消时刻已完成的工序和正在加工的工序，以及没加工的工序
Unfi_chrom_decode=initial_schedule.decode;
finish_oper=zeros(all_oper,13);   %用于存已加工工序信息
processing_oper=zeros(all_oper,13);   %用于存正在加工工序信息
unfinish_oper=zeros(all_oper,13);   %用于存未加工工序信息
Unfi_initial_time=cell(fa_num,wo_num_max);   %用于存订单取消后剩余工件在各机器上的初始加工时间
Unfi_wo_time_load=zeros(machine_num,1);
P_move=10;    %% 工件移动消耗的单位能耗
z=1;
zz=1;
zzz=1;
for i=1:all_oper 
    Unfi_chrom_decode1=Unfi_chrom_decode;
    if Unfi_chrom_decode1(i,7)<time&&Unfi_chrom_decode1(i,8)<=time
        finish_oper(z,:)=Unfi_chrom_decode1(i,:);    %已加工工序的信息
        z=z+1;
    elseif Unfi_chrom_decode1(i,7)<time&&Unfi_chrom_decode1(i,8)>time
        processing_oper(zz,:)=Unfi_chrom_decode1(i,:);    %正在加工工序的信息
        zz=zz+1;
    else
        unfinish_oper(zzz,:)=Unfi_chrom_decode1(i,:);     %未加工工序的信息
        zzz=zzz+1;
    end
end
finish_oper(all(finish_oper==0,2),:)=[];  %删除矩阵中所有的零行；
processing_oper(all(processing_oper==0,2),:)=[];
unfinish_oper(all(unfinish_oper==0,2),:)=[];

%%完成度规则：
%1、判断正在加工工序是不是被取消工件的工序
%2、该工件已完工工序的成本与该工序已加工的成本的和与整个工件的总成本的比值为m，若m>m1,则将该工件剩余的所有工序加工完制成成品；
%3、若m2<m<m1,则加工完当前工序制成半成品；
%4、若m<m2,则判断当前工序的已加工时间与总时间的比值，若达到阈值m3就继续加工制成半成品，若未达到就放弃加工该工序报废。 
pro_oper_num=size(processing_oper,1);
fin_oper_num=size(finish_oper,1);
num=1;
m1=0.75;
m2=0.6;
m3=0.7;
for zn=1:pro_oper_num
    S_time=processing_oper(zn,7);
    processing_time=time-S_time;
    processing_oper(zn,6)=processing_time;    %更新正在加工工序已经加工的时间
    job_rank=processing_oper(zn,1);
    job_oper=processing_oper(zn,2);
    [~,po]=find(CanW_num1==job_rank);
    [po1,~]=find(Unfi_chrom_decode(:,1)==job_rank);
    zz=(po1(job_oper));
    if isempty(po)
        finish_oper(fin_oper_num+num,:)=Unfi_chrom_decode(zz,:);
    else 
        [po2,~]=find(finish_oper(:,1)==job_rank);
        time1=finish_oper(po2,6);
        cost1=finish_oper(po2,13);
        i=time1.*cost1;
        time2=processing_oper(zn,6);
        protime=Unfi_chrom_decode(zz,6);
        procost=Unfi_chrom_decode(zz,13);
        cost2=procost/protime;
        ii=time2.*cost2;
        time3=Unfi_chrom_decode(po1,6);
        cost3=Unfi_chrom_decode(po1,13);
        iii=time3.*cost3;
        m=(sum(i)+ii)/sum(iii);
       if m>m1
          finish_oper(fin_oper_num+num,:)=Unfi_chrom_decode(zz,:);
          CanW_num1(po)=[];    %将该工件从取消订单中删除（加工成成品）
       elseif (m2<m)&&(m<m1)
           finish_oper(fin_oper_num+num,:)=Unfi_chrom_decode(zz,:);     %加工成半成品
       else
           t=time2/protime;
           if t>m3
              finish_oper(fin_oper_num+num,:)=Unfi_chrom_decode(zz,:);   %加工成半成品
           else
               finish_oper(fin_oper_num+num,:)=processing_oper(zn,:);   %报废
               jj=find(finish_oper(:,1)==job_rank);
               finish_oper(jj,:)=[];   %报废
           end
       end
    end
    num=num+1;
end
%若被取消工件没有正在加工的工序 判断该工件在订单取消时刻所有工序是否都加工完 若该工件已经是成品 将该工件直接删除
%若该工件是半成品 则判断该工件已加工工序的成本与总成本的比值，若大于m1,则加工成成品，否则不继续加工后面的剩余工序，加工成半成品
pro_ope(1,:)=processing_oper(:,1);
pro_oper=unique(pro_ope);
CanW=ismember(CanW_num1,pro_oper);
CanW1=CanW_num1(~CanW);
CanW12=size(CanW1,2);
if ~isempty(CanW1)
    for o=1:CanW12
        job=CanW1(o);
        [~,z00]=find(CanW_num1==job);
        [z11,~]=find(unfinish_oper(:,1)==job);
        if isempty(z11)
            [z12,~]=find(finish_oper(:,1)==job);
            finish_oper(z12,:)=[];
            CanW_num1(z00)=[];
        else
            [z0,~]=find(finish_oper(:,1)==job);
            [z1,~]=find(Unfi_chrom_decode(:,1)==job);
            time1=finish_oper(z0,6);
            cost1=finish_oper(z0,13);
            i=time1.*cost1;
            time2=Unfi_chrom_decode(z1,6);
            cost2=Unfi_chrom_decode(z1,13);
            ii=time2.*cost2;
            d=sum(i)/sum(ii);
            if d>m1
                CanW_num1(z00)=[];%将该工件从取消订单中删除（加工成成品）
            else
            end
        end
    end
    w=size(CanW_num1,2);
    for x=1:w
        s=find(unfinish_oper(:,1)==CanW_num1(1,x)');
        unfinish_oper(s,:)=[];    %将取消的工件从未加工工件中删除
    end
else
    w=size(CanW_num1,2);
    for x=1:w
        s=find(unfinish_oper(:,1)==CanW_num1(1,x)');
        unfinish_oper(s,:)=[];    %将取消的工件从未加工工件中删除
    end
end
processing_oper=[];
finish_oper(all(finish_oper==0,2),:)=[];  %删除矩阵中所有的零行；
unfinish_oper(all(unfinish_oper==0,2),:)=[];

%计算已加工工序的能耗
finish_oper_num=size(finish_oper,1);
finish_oper_energy=0;
for stage=1:finish_oper_num
    pro_time_stage=finish_oper(stage,6);   %读取加工时间
    move_time=finish_oper(stage,11);
    power_one=finish_oper(stage,12);
    finish_oper_energy=finish_oper_energy+power_one*pro_time_stage+move_time*P_move;
end
%%找出每台机器在订单取消时刻的最大加工时间
for n1=1:fa_num
    [o1,~]=find(finish_oper(:,3)==n1);   %找出所有1、2工厂的工序
    finish_oper1=finish_oper(o1,:);
    for n2=1:wo_num_max                   
        [o2,~]=find( finish_oper1(:,4)==n2);   %找出1、2车间的工序
        finish_oper2= finish_oper1(o2,:);
        for n3=1:machine_num
            [o3,~]=find(finish_oper2(:,5)==n3);    %找出1、2、3、4机器的工序
            finish_oper3=finish_oper2(o3,:);
            time_max=max(finish_oper3(:,8));
            if ~isempty(time_max)
                if time_max>time
                    time_max=time_max+0;
                else
                    time_max=time;
                end
                Unfi_wo_time_load(n3,:)=time_max;
            else
                Unfi_wo_time_load(n3,:)=time;
            end
            clear o3  finish_oper3
        end
        Unfi_wo_time_load1=num2cell(Unfi_wo_time_load,[1,2]);  %将double转换为cell数组，因为cell不能直接存double
        Unfi_initial_time(n1,n2)=Unfi_wo_time_load1;
        clear o2  finish_oper2
    end
    clear o1  finish_oper1
end
end