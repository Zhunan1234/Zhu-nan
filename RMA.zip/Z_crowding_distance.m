function [population_st]=Z_crowding_distance(Population_ns,Obj_num)
%求个体的拥挤距离

% inputs
% pop_ns：非支配排序之后的种群
% chrom_length:染色体长度
% T_Obj_num：目标数

% outputs
% pop_cd:某一前沿计算过拥挤距离的种群
population_st=Population_ns;
array=[Population_ns.rank];
rank_count=max(array);     % 共有多少个等级
for rank=1:rank_count      % 为每个等级计算拥挤距离
    [~,vol]=find(array==rank);
    pop_array=Population_ns(vol);   % 取出当前等级
    s=size(vol,2);                  
    obj2=zeros(s,2);                        %循环完之后需要清零
    obj3=zeros(s,2);
    for p=1:s
        pop_array(p).crowded_distance=0;    % 将拥挤度清0
    end
    obj_array=zeros(s,Obj_num+1);
    for j=1:s
        obj_array(j,1:Obj_num)=pop_array(j).objectives;    %取出对应个体的目标值
        obj_array(j,Obj_num+1)=0;                          %用于存放拥挤距离
    end
    obj_array1=obj_array;
    for i=1:Obj_num
        [ai,bi]=sort(obj_array1(:,i));          %分别对每个目标值进行排序，便于查重，并记录排序后元素在未排序前对应的位置bi，方便复原
        obj_array1(:,i)=ai;
        [L,D]=unique(obj_array(:,i));           %对每个目标进行去重操作，并记录重首的位置为D
        L1=size(L,1);
        obj1=zeros(L1,2);                       %用于存储查重后单个目标的值和拥挤距离，便于后期汇总
        for D1=1:L1
        obj1(D1,1)=L(D1);
        end
        %%求解拥挤距离
        obj1(1,2)=obj1(1,2)+inf;                 %首尾端点的拥挤距离是无穷大
        obj1(size(L,1),2)=obj1(size(L,1),2)+inf;
        if size(L,1)>2                           %除掉首尾端点的中间目标值拥挤距离计算
            for ii=2:size(L,1)-1
                max_obj=max(obj1(:,1));
                min_obj=min(obj1(:,1));
                distance=(obj1(ii+1,1)-obj1(ii-1,1))/(max_obj-min_obj);
                obj1(ii,2)=obj1(ii,2)+distance;
            end   
        else
            obj1(:,2)=inf;
        end
        %%将重复值再插入进去
        for m=1:size(D,1)    %%将去重之后的值存入全为0的数组，此时重复值对应的位置数值为0
            [v,~]=find(obj1(m,1)==obj_array1(:,i));
            vo=size(v,1);
            if vo==1   
            obj2(v,:)=obj1(m,:);
            else
            obj2(v(1),:)=obj1(m,:);
            end
        end
        [index,~]=find(obj2(:,1)==0);            %%找到重复值所在的位置
        if  ~isempty(index)
            for iii=1:size(index,1)
                obj3(index(iii),1)=obj3(index(iii),1)+obj_array1(index(iii),i);  %%将重复值放入另一个数组中，在该数组中被重复值对应位置数值为0
            end
            obj2=obj2+obj3;           %%得到插入重复值后的数组，此时该数组关于重复值的拥挤距离还没插入
            for jj=1:size(index,1)    
                obj2(index(jj),2)=obj2(index(jj)-1,2);    %%找到重复值的拥挤距离
            end
        else
            obj2=obj2+0;
        end
        [~,ci]=sort(bi);          %%将数组各元素恢复到未排序前的位置
        obj=obj2(ci,:); 
        obj_array(:,i)=obj(:,1);
        obj_array(:,Obj_num+1)=obj_array(:,Obj_num+1)+obj(:,2);
        obj1(:,:)=0;
        obj2(:,:)=0;
        obj3(:,:)=0;
    end
    for n=1:s                     % 存入拥挤距离
        pop_array(n).crowded_distance=obj_array(n,Obj_num+1);
    end
    population_st(vol)=pop_array;
    clear pop_array obj_array
end
end

        