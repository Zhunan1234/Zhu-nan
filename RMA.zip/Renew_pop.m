function [renew_pop,repeat_size,chromesome]=Renew_pop(Population_home_ns,pop_size,job_num,machine_num,job_infor,all_oper,ope_set,Obj_num,fa_num,wo_num_max)
%% ɾ���ظ�����(Ŀ��ֵ��ͬ���϶���ͬ)������pop_size,������ɲ���
POP=Population_home_ns;
chrom_all=(reshape([POP.objectives],[Obj_num,pop_size]))';
[C,ia,ic] = unique(chrom_all,'rows');
index=ia';
POP_new=POP(index);
pop_num=size(POP_new,2);
plus_num=pop_size-pop_num;
[pop_plus]=initialization(job_infor,job_num,plus_num,all_oper,ope_set,fa_num,wo_num_max,machine_num);
[pop_plus]=decode(pop_plus,plus_num,job_num,machine_num,all_oper,fa_num,wo_num_max,ope_set,job_infor);
renew_pop=POP_new;
renew_pop(pop_num+1:pop_size)=pop_plus;
[renew_pop]=nondominant_sort(renew_pop,pop_size,Obj_num);
[renew_pop]=Z_crowding_distance(renew_pop,Obj_num);
repeat_size=plus_num;
end