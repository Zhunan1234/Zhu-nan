function [Population_ch,Population_first]=selectPopulate(Population_st,pop_size)
%ѡ��һ����Ŀ�ĸ���

%inputs
%Population_home:�����ֲ���������Ⱥ
% pop_size:��Ⱥ��ģ

%outpuuts
%Population_st:��������
% pop_size:��Ⱥ��ģ

Population_rank=[Population_st.rank];
child_rank=Population_rank(1:pop_size);
last_rank=child_rank(pop_size);
[~,col]=find(Population_rank==1);
Population_first=Population_st(col);
Population_ch=Population_st(col);
if last_rank==1
    [~,col]=find(Population_rank==last_rank);
    Population_first=Population_st(col);
else
    [value1,~]=find(Population_rank==last_rank);
    [value2,~]=find(child_rank==last_rank);
    [~,last_rank_size1]=size(value1);
    [~,last_rank_size2]=size(value2);
    if last_rank_size1==last_rank_size2
        Population_ch(1:pop_size)=Population_st(1:pop_size);
    else
        num=pop_size-last_rank_size2;
        Population_ch(1:num)=Population_st(1:num);
        Population_array=Population_st(num+1:num+last_rank_size1);
        array=[Population_array.crowded_distance];
        [~,array_sort_col]=sort(array,'descend');
        index=array_sort_col(1:last_rank_size2);
        Population_ch(num+1:pop_size)=Population_array(index);
    end
end
end