function [con]=Unfi_judge(job_rank,ope_rank,fa_rank,wo_rank,ma_rank,Unfi_chrom_decode,finish_oper)
pre_ope=ope_rank-1;
[s0,~]=find(finish_oper(:,1)==job_rank);
[s1,~]=find(finish_oper(s0,2)==pre_ope);
s2=s0(s1);
if ~isempty(s2)
    [s3,~]=find(Unfi_chrom_decode(:,1)==job_rank);
    [s4,~]=find(Unfi_chrom_decode(s3,2)==pre_ope);
    s5=s3(s4);
    pre_fa_rank=Unfi_chrom_decode(s5,3);
    pre_wo_rank=Unfi_chrom_decode(s5,4);
    pre_ma_rank=Unfi_chrom_decode(s5,5);
else
    pre_fa_rank=finish_oper(s2,3);
    pre_wo_rank=finish_oper(s2,4);
    pre_ma_rank=finish_oper(s2,5);
end
if pre_fa_rank==fa_rank
    if pre_wo_rank==wo_rank
        if pre_ma_rank==ma_rank
            k=1;   %表示前后两道工序在同一工厂的同一车间的同一机器加工，无需移动
        else
            k=2;   %表示在同一工厂的同一车间加工，需要进行机器间的移动
        end
    else
        k=3;   %表示在同一工厂的不同车间进行移动
    end
else
    k=4;    %表示在不同工厂加工，需要进行工厂移动
end
con=k;
end

   
