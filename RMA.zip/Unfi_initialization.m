function [Unfi_pop_st]=Unfi_initialization(job_infor,pop_size,unfi_oper_set,fa_num,wo_num_max,machine_num,oper_set)
%% 订单取消的初始化规则（针对工厂、车间、机器，不针对工序）
%1 后道工序优先安排与前道工序相同的工厂车间机器。需要注意的时，工厂层级不同，后续的安排就需要按照其他规则进行生产。
%1.1	若工厂相同，但车间与前道工序不同，在可选加工车间中选择累计加工时间最短的车间
%1.2	若工厂、车间相同，在可选加工机器中选择累计加工时间最少的机器
%2 在上述规则不能安排的情况下，按照可选工厂，可选车间、可选机器的累计加工时间最短优先分配
Unfi_oper_num=size(unfi_oper_set,2);
chromesome=zeros(6,Unfi_oper_num);
fa_num2=fa_num;
%%第一行存工厂，第二行存车间，第三行存机器，第四行存工件工序，第五行加工时间,第六行加工成本
Unfi_pop_st(1:pop_size)=struct('chromesome',[],'decode',[],'pro_time',[],'objectives',[],'factory_load',[],'work_load',[],'mach_load',[],'rank',0,'critical_path',[],'crowded_distance',0);
for num=1:pop_size
    %%工件排序
    chrom(1,:)=unfi_oper_set(1,:);
    chrom(2,:)=unfi_oper_set(2,:);
    in=randperm(Unfi_oper_num);
    chromesome(4,1:Unfi_oper_num)=chrom(1,in);    %随机工序排序
    TO_sum=cell(fa_num2,wo_num_max);    %记录车间内各机器的累计加工时间
    PRO_sum=zeros(1,machine_num);
    PRO_sum_fa=zeros(1,fa_num2);
    PRO_sum_wo=zeros(fa_num2,wo_num_max);
    TO_sum_C=cell(fa_num2,wo_num_max);    %记录车间内各机器的累计加工成本
    PRO_sum_C=zeros(1,machine_num);     %记录每个机器的加工成本
    PRO_sum_Cfa=zeros(1,fa_num2);      %记录每个工厂的加工成本
    PRO_sum_Cwo=zeros(fa_num2,wo_num_max);     %记录每个车间的加工成本
    for i=1:fa_num2
        for ii=1:wo_num_max
            TO_sum{i,ii}=PRO_sum;
        end
        for ii=1:wo_num_max
            TO_sum_C{i,ii}=PRO_sum_C;
        end
    end
    a=unfi_oper_set(1,:);
    job_set=unique(a);
    job_zz=size(job_set,2);
    num2=0;
    for i=1:job_zz
        job_rank=job_set(1,i);
        [~,lo]=find(unfi_oper_set(1,:)==job_rank);
        job_oper=size(lo,2);
        for ii=1:job_oper
            z=num2+1;
            if ii==1      %每个工件只有一道工序
               lo2=unfi_oper_set(2,z);
               pre_oper=lo2-1;
               NO_p=sum(oper_set(2,1:job_rank-1))+pre_oper;
               avai_fa_set=(job_infor(NO_p+1).fa_rank)';
               fa_time=PRO_sum_fa(1,avai_fa_set);
               [~,PO]=find(min(fa_time)==fa_time);
               m=randperm(size(PO,2),1);
               fa_rank=avai_fa_set(1,PO(m));
               chromesome(1,z)=fa_rank;
               avai_wo_set=job_infor(NO_p+1).wo_rank(PO(m),:);
               [~,position2]=find(avai_wo_set==0);
               avai_wo_set(position2)=[];
               wo_time=PRO_sum_wo(fa_rank,avai_wo_set);
               [~,PO1]=find(min(wo_time)==wo_time);
               m1=randperm(size(PO1,2),1);
               wo_rank=avai_wo_set(1,PO1(m1));
               chromesome(2,z)=wo_rank;
               avai_ma_set=job_infor(NO_p+1).mach_rank{PO(m),PO1(m1)};
               PROTIME=TO_sum{fa_rank,wo_rank};
               PROCOST=TO_sum_C{fa_rank,wo_rank};
               ma_time=PROTIME(1,avai_ma_set);
               [~,PO2]=find(min(ma_time)==ma_time);
               m2=randperm(size(PO2,2),1);
               ma_rank=avai_ma_set(1,PO2(m2));
               chromesome(3,z)=ma_rank;
               protime=job_infor(NO_p+1).pro_time{PO(m),PO1(m1)}(1,PO2(m2));
               procost=(job_infor(NO_p+1).unit_cost{PO(m),PO1(m1)}(1,PO2(m2)))*protime;
               chromesome(5,z)=protime;
               chromesome(6,z)=procost;
               PROTIME(1,ma_rank)=PROTIME(1,ma_rank)+protime;
               TO_sum{fa_rank,wo_rank}=PROTIME;    %更新机器、车间、工厂的累计加工时间
               PRO_sum_wo(fa_rank,wo_rank)=PRO_sum_wo(fa_rank,wo_rank)+protime;
               PRO_sum_fa(1,fa_rank)=PRO_sum_fa(1,fa_rank)+protime;
               PROCOST(1,ma_rank)=PROCOST(1,ma_rank)+procost;
               TO_sum_C{fa_rank,wo_rank}=PROCOST;    %更新机器、车间、工厂的累计加工成本
               PRO_sum_Cwo(fa_rank,wo_rank)=PRO_sum_Cwo(fa_rank,wo_rank)+procost;
               PRO_sum_Cfa(1,fa_rank)=PRO_sum_Cfa(1,fa_rank)+procost;
            else
               lo2=unfi_oper_set(2,z);
               pre_oper=lo2-1;
               NO_p=sum(oper_set(2,1:job_rank-1))+pre_oper;
               pre_fa=chromesome(1,z-1);  %%前道的加工工厂
               pre_wo=chromesome(2,z-1);  %%前道的加工车间
               %%取出当前工序的可加工车间，判断是否存在可选工厂与前道工厂
               avai_fa_set=job_infor(NO_p+1).fa_rank;
               [ID,~]=find(pre_fa==avai_fa_set);
               if ~isempty(ID)                %存在可选工厂与上个工序的加工工厂相同
                  chromesome(1,z)=pre_fa;
                  avai_wo_set=job_infor(NO_p+1).wo_rank(ID,:);
                  [~,ID1]=find(avai_wo_set==pre_wo);
                  if ~isempty(ID1)                   %%工厂、车间都相同
                     chromesome(2,z)=pre_wo;
                     avai_ma_set=job_infor(NO_p+1).mach_rank{ID,ID1};
                     PROTIME=TO_sum{pre_fa,pre_wo};
                     PROCOST=TO_sum_C{pre_fa,pre_wo};
                     current_sum=PROTIME(1,avai_ma_set);
                     [~,ID2]=find(current_sum==min(current_sum));
                     m3=randperm(size(ID2,2),1);
                     ma_rank=avai_ma_set(1,ID2(m3));
                     chromesome(3,z)=ma_rank;
                     protime=job_infor(NO_p+1).pro_time{ID,ID1}(1,ID2(m3));
                     chromesome(5,z)=protime;
                     procost=(job_infor(NO_p+1).unit_cost{ID,ID1}(1,ID2(m3)))*protime;
                     chromesome(6,z)=procost;
                     PROTIME(1,ma_rank)=PROTIME(1,ma_rank)+protime;
                     TO_sum{pre_fa,pre_wo}=PROTIME;    %更新机器、车间、工厂的累计加工时间
                     PRO_sum_wo(pre_fa,pre_wo)=PRO_sum_wo(pre_fa,pre_wo)+protime;
                     PRO_sum_fa(1,pre_fa)=PRO_sum_fa(1,pre_fa)+protime;
                     PROCOST(1,ma_rank)=PROCOST(1,ma_rank)+procost;
                     TO_sum_C{pre_fa,pre_wo}=PROCOST;    %更新机器、车间、工厂的累计加工成本
                     PRO_sum_Cwo(pre_fa,pre_wo)=PRO_sum_Cwo(pre_fa,pre_wo)+procost;
                     PRO_sum_Cfa(1,pre_fa)=PRO_sum_Cfa(1,pre_fa)+procost;
                  else     %工厂相同，车间不同
                      [~,position1]=find(avai_wo_set==0);
                      avai_wo_set(position1)=[];               %%消除多余的0
                      wo_time=PRO_sum_wo(pre_fa,avai_wo_set);
                      [~,ID3]=find(min(wo_time)==wo_time);
                      m4=randperm(size(ID3,2),1);
                      wo_rank=avai_wo_set(1,ID3(m4));
                      [~,ID4]=find(wo_rank==job_infor(NO_p+1).wo_rank(ID,:));
                      chromesome(2,z)=wo_rank;
                      avai_ma_set=job_infor(NO_p+1).mach_rank{ID,ID4};
                      PROTIME=TO_sum{pre_fa,wo_rank};
                      PROCOST=TO_sum_C{pre_fa,wo_rank};
                      ma_time=PROTIME(1,avai_ma_set);
                      [~,ID5]=find(min(ma_time)==ma_time);
                      m5=randperm(size(ID5,2),1);
                      ma_rank=avai_ma_set(1,ID5(m5));
                      chromesome(3,z)=ma_rank;
                      protime=job_infor(NO_p+1).pro_time{ID,ID4}(1,ID5(m5));
                      chromesome(5,z)=protime;
                      procost=(job_infor(NO_p+1).unit_cost{ID,ID4}(1,ID5(m5)))*protime;
                      chromesome(6,z)=procost;
                      PROTIME(1,ma_rank)=PROTIME(1,ma_rank)+protime;
                      TO_sum{pre_fa,wo_rank}=PROTIME;    %更新机器、车间、工厂的累计加工时间
                      PRO_sum_wo(pre_fa,wo_rank)=PRO_sum_wo(pre_fa,wo_rank)+protime;
                      PRO_sum_fa(1,pre_fa)=PRO_sum_fa(1,pre_fa)+protime;
                      PROCOST(1,ma_rank)=PROCOST(1,ma_rank)+procost;
                      TO_sum_C{pre_fa,wo_rank}=PROCOST;    %更新机器、车间、工厂的累计加工成本
                      PRO_sum_Cwo(pre_fa,wo_rank)=PRO_sum_Cwo(pre_fa,wo_rank)+procost;
                      PRO_sum_Cfa(1,pre_fa)=PRO_sum_Cfa(1,pre_fa)+procost;
                  end
               else      %可选工厂与上道工序的工厂不同
                   avai_fa_set=(job_infor(NO_p+1).fa_rank)';
                   fa_time=PRO_sum_fa(1,avai_fa_set);
                   [~,ID6]=find(min(fa_time)==fa_time);
                   m6=randperm(size(ID6,2),1);
                   fa_rank=avai_fa_set(1,ID6(m6));
                   chromesome(1,z)=fa_rank;
                   avai_wo_set=job_infor(NO_p+1).wo_rank(ID6(m6),:);
                   wo_time=PRO_sum_wo(fa_rank,avai_wo_set);
                   [~,ID7]=find(min(wo_time)==wo_time);
                   m7=randperm(size(ID7,2),1);
                   wo_rank=avai_wo_set(1,ID7(m7));
                   chromesome(2,z)=wo_rank;
                   avai_ma_set=job_infor(NO_p+1).mach_rank{ID6(m6),ID7(m7)};
                   PROTIME=TO_sum{fa_rank,wo_rank};
                   PROCOST=TO_sum_C{fa_rank,wo_rank};
                   ma_time=PROTIME(1,avai_ma_set);
                   [~,ID8]=find(min(ma_time)==ma_time);
                   m8=randperm(size(ID8,2),1);
                   ma_rank=avai_ma_set(1,ID8(m8));
                   chromesome(3,z)=ma_rank;
                   protime=job_infor(NO_p+1).pro_time{ID6(m6),ID7(m7)}(1,ID8(m8));
                   chromesome(5,z)=protime;
                   procost=(job_infor(NO_p+1).unit_cost{ID6(m6),ID7(m7)}(1,ID8(m8)))*protime;
                   chromesome(6,z)=procost;
                   PROTIME(1,ma_rank)=PROTIME(1,ma_rank)+protime;
                   TO_sum{fa_rank,wo_rank}=PROTIME;    %更新机器、车间、工厂的累计加工时间
                   PRO_sum_wo(fa_rank,wo_rank)=PRO_sum_wo(fa_rank,wo_rank)+protime;
                   PRO_sum_fa(1,fa_rank)=PRO_sum_fa(1,fa_rank)+protime;
                   PROCOST(1,ma_rank)=PROCOST(1,ma_rank)+procost;
                   TO_sum_C{fa_rank,wo_rank}=PROCOST;    %更新机器、车间、工厂的累计加工成本
                   PRO_sum_Cwo(fa_rank,wo_rank)=PRO_sum_Cwo(fa_rank,wo_rank)+procost;
                   PRO_sum_Cfa(1,fa_rank)=PRO_sum_Cfa(1,fa_rank)+procost;
               end
            end
            num2=num2+1;
        end
    end
    Unfi_pop_st(num).chromesome=chromesome;
end
end
        
                   
                      
                  
               
        